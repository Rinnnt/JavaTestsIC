public class PQException extends Exception {

  public PQException(String msg) {
    super(msg);
  }
}
