package aeroplane;

import static org.junit.Assert.assertEquals;

import java.util.Set;
import org.junit.Test;

public class Question5Tests {

  /*
  @Test
  public void testCountAdultsCrew() {
    final Set<CrewMember> passengers = Set.of(
            new CrewMember("Amy", "Jackson"),
            new CrewMember("Rita", "May"),
            new CrewMember("Ha", "Cole"),
            new CrewMember("Tingting", "Li"));
    assertEquals(4, SeatAllocator.countAdults(passengers));
  }

  @Test
  public void testCountAdultsEconomy() {
    final Set<EconomyClassPassenger> passengers = Set.of(
            new EconomyClassPassenger("Ally", "Donaldson", 40),
            new EconomyClassPassenger("Felix", "Donaldson", 8),
            new EconomyClassPassenger("Poppy", "Donaldson", 11),
            new EconomyClassPassenger("Kitty", "Donaldson", 4),
            new EconomyClassPassenger("Chris", "Donaldson", 40));
    assertEquals(2, SeatAllocator.countAdults(passengers));
  }

  @Test
  public void testCountAdultsBusiness() {
    final Set<BusinessClassPassenger> passengers = Set.of(
            new BusinessClassPassenger("Ally", "Donaldson", 47, Luxury.CHAMPAGNE),
            new BusinessClassPassenger("Felix", "Donaldson", 15, Luxury.TRUFFLES),
            new BusinessClassPassenger("Poppy", "Donaldson", 18, Luxury.CHAMPAGNE),
            new BusinessClassPassenger("Kitty", "Donaldson", 12, Luxury.STRAWBERRIES),
            new BusinessClassPassenger("Chris", "Donaldson", 47, Luxury.CHAMPAGNE));
    assertEquals(3, SeatAllocator.countAdults(passengers));
  }

  @Test
  public void testCountAdultsMixture() {
    final Set<Passenger> passengers = Set.of(
            new BusinessClassPassenger("Felix", "Donaldson", 15, Luxury.TRUFFLES),
            new BusinessClassPassenger("Kitty", "Donaldson", 12, Luxury.STRAWBERRIES),
            new EconomyClassPassenger("Poppy", "Donaldson", 11)
    );
    assertEquals(0, SeatAllocator.countAdults(passengers));
  }
   */

}
