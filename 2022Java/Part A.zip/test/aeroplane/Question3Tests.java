package aeroplane;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.assertTrue;

import java.util.HashSet;
import java.util.Set;
import org.junit.Test;

public class Question3Tests {

  /*
  @Test
  public void testEquality1() {
    assertNotEquals(null, new Seat(1, 'A'));
  }

  @Test
  public void testEquality2() {
    assertNotEquals(new Seat(1, 'A'), new Object());
  }

  @Test
  public void testEquality3() {
    assertNotEquals(new Seat(1, 'A'), new Seat(1, 'B'));
  }

  @Test
  public void testEquality4() {
    assertNotEquals(new Seat(1, 'A'), new Seat(2, 'A'));
  }

  @Test
  public void testEquality5() {
    assertNotEquals(new Seat(1, 'A'), new Seat(2, 'B'));
  }

  @Test
  public void testEquality6() {
    final Seat seat = new Seat(2, 'C');
    assertEquals(seat, seat);
  }

  @Test
  public void testEquality7() {
    assertEquals(new Seat(30, 'D'), new Seat(30, 'D'));
  }

  @Test
  public void testEquality8() {
    final Set<Seat> seatSet = new HashSet<>();
    seatSet.add(new Seat(30, 'E'));
    assertTrue(seatSet.contains(new Seat(30, 'E')));
  }
   */

}
