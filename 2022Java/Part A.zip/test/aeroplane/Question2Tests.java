package aeroplane;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class Question2Tests {

  /*
  @Test
  public void testIsAdultCrew() {
    final Passenger crewMember = new CrewMember("Deepti", "James");
    assertTrue(crewMember.isAdult());
  }

  @Test
  public void testIsAdultEconomy() {
    final Passenger economy = new EconomyClassPassenger("Xi", "Fox", 18);
    assertTrue(economy.isAdult());
  }

  @Test
  public void testIsAdultBusiness() {
    final Passenger economy = new BusinessClassPassenger("Alain", "Gerard", 59, Luxury.CHAMPAGNE);
    assertTrue(economy.isAdult());
  }

  @Test
  public void testNotIsAdultEconomy() {
    final Passenger economy = new EconomyClassPassenger("Kiwi", "Zhang", 0);
    assertFalse(economy.isAdult());
  }

  @Test
  public void testNotIsAdultBusiness() {
    final Passenger economy = new BusinessClassPassenger("Lauren", "Ace", 17, Luxury.TRUFFLES);
    assertFalse(economy.isAdult());
  }

  @Test
  public void testToStringCrew() {
    final Passenger crewMember = new CrewMember("Deepti", "James");
    assertEquals("Crew member: Deepti James", crewMember.toString());
  }

  @Test
  public void testToStringEconomy() {
    final Passenger economy = new EconomyClassPassenger("Kiwi", "Zhang", 0);
    assertEquals("Economy class passenger: Kiwi Zhang, age 0", economy.toString());
  }

  @Test
  public void testToStringBusiness1() {
    final Passenger economy = new BusinessClassPassenger("Lauren", "Ace", 17,
            Luxury.TRUFFLES);
    assertEquals("Business class passenger: Lauren Ace, age 17, likes truffles",
            economy.toString());
  }

  @Test
  public void testToStringBusiness2() {
    final Passenger economy = new BusinessClassPassenger("John", "Warren", 42,
            Luxury.CHAMPAGNE);
    assertEquals("Business class passenger: John Warren, age 42, likes champagne",
            economy.toString());
  }

  @Test
  public void testToStringBusiness3() {
    final Passenger economy = new BusinessClassPassenger("Mary", "de Vries", 20,
            Luxury.STRAWBERRIES);
    assertEquals("Business class passenger: Mary de Vries, age 20, likes strawberries",
            economy.toString());
  }
   */

}
