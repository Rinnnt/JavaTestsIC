package aeroplane;

public abstract class Passenger {

  // TODO: Complete during Section A, question 2

}
