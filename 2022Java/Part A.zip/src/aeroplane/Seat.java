package aeroplane;

public class Seat {

  // TODO: Complete during Section A, questions 1 and 3

}

