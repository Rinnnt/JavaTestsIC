package aeroplane;

import java.io.Serial;

public class AllocationNotPossibleException extends Exception {

  @Serial
  private static final long serialVersionUID = 1L;

}
