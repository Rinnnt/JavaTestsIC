package alphatree;

import java.util.List;

public class AlphaFreq {

  public AlphaFreq() {
    // TODO: Question 2
  }

  public AlphaFreq(List<Character> cs) {
    // TODO: Question 2
  }

  public boolean isEmpty() {
    // TODO: Question 2
    return false;
  }

  public int size() {
    // TODO: Question 2
    return 0;
  }

  public int get(char c) {
    // TODO: Question 2
    return 0;
  }

  public void add(char c) {
    // TODO: Question 2
  }

  public void reset() {
    // TODO: Question 2
  }
}
