package alphatree;

public class AlphaTreeQueue {

  public AlphaTreeQueue() {
    // TODO: Question 3
  }

  public AlphaTreeQueue(AlphaFreq freqs) {
    // TODO: Question 3
  }

  public void addAll(AlphaFreq freqs) {
    // TODO: Question 3
  }

  public void add(AlphaTree t) {
    // TODO: Question 3
  }

  public AlphaTree peek() {
    // TODO: Question 3
    return null;
  }

  public AlphaTree poll() {
    // TODO: Question 3
    return null;
  }

  public int size() {
    // TODO: Question 3
    return 0;
  }
}
