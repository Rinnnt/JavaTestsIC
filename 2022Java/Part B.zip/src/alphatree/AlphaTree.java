package alphatree;

import java.util.Set;

public final class AlphaTree {

  public AlphaTree() {
    // TODO: Question 1
  }

  public AlphaTree(char c, int weight) {
    // TODO: Question 1
  }

  public AlphaTree(AlphaTree lt, AlphaTree rt) {
    // TODO: Question 1
  }

  public boolean isEmpty() {
    // TODO: Question 1
    return false;
  }

  public boolean isSingleton() {
    // TODO: Question 1
    return false;
  }

  public AlphaTree left() {
    // TODO: Question 1
    return null;
  }

  public AlphaTree right() {
    // TODO: Question 1
    return null;
  }

  public Set<Character> chars() {
    // TODO: Question 1
    return null;
  }

  public int freq() {
    // TODO: Question 1
    return 0;
  }
}
