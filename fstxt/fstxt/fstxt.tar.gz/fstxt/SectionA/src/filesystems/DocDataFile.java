package filesystems;

public class DocDataFile {

}
