package filesystems;

public class DocDirectory {

}
