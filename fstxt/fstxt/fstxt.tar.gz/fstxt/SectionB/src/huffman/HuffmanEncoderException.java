package huffman;

public class HuffmanEncoderException extends RuntimeException {

  public HuffmanEncoderException() {
    super();
  }

  public HuffmanEncoderException(String message) {
    super(message);
  }
}
