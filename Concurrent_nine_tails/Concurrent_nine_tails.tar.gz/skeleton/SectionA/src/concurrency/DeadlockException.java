package concurrency;

@SuppressWarnings("serial")
public class DeadlockException extends Exception {

}
