public class PQException extends RuntimeException{

	public PQException(String s){
		super(s);
	}//end constructor

} //end Priority Queue Exception
