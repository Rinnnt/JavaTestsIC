package testutils;

import domain.producttypes.ExchangeableChemical;

public class MockChemical extends ExchangeableChemical {}
