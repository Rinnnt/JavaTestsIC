package datastructures;

import domain.Player;
import domain.producttypes.ExchangeableChemical;
import java.util.Optional;

public class StockImpl<E extends ExchangeableChemical> implements Stock<E> {

  @Override
  public void push(E element, Player player) {
    // TODO: Q2/Q4
  }

  @Override
  public Optional<E> pop() {
    // TODO: Q2/Q4
    return Optional.empty();
  }

  @Override
  public int size() {
    // TODO: Q2/Q4
    return -1;
  }
}
