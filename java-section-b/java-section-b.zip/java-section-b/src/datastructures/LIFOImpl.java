package datastructures;

import java.util.Optional;
import java.util.Stack;

public class LIFOImpl<E> implements LIFO<E> {

  private Stack<E> stack;

  public LIFOImpl() {
    stack = new Stack<>();
  }

  @Override
  public void push(E item) {
    stack.push(item);
  }

  @Override
  public Optional<E> pop() {
    // TODO: Q1
    return Optional.empty();
  }

  @Override
  public int size() {
    // TODO: Q1
    return -1;
  }
}
