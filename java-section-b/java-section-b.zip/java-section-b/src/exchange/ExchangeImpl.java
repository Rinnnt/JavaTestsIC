package exchange;

import chemicals.Carbon;
import chemicals.Hydrogen;
import chemicals.Methane;
import domain.Player;
import java.util.Optional;

public class ExchangeImpl implements Exchange {

  @Override
  public void sellHydrogen(Hydrogen item, Player player) {
    // TODO Q3
  }

  @Override
  public Optional<Hydrogen> buyHydrogen() {
    // TODO Q3
    return null;
  }

  @Override
  public void sellCarbon(Carbon item, Player player) {
    // TODO Q3
  }

  @Override
  public Optional<Carbon> buyCarbon() {
    // TODO Q3
    return null;
  }

  @Override
  public void sellMethane(Methane item, Player player) {
    // TODO Q3
  }

  @Override
  public Optional<Methane> buyMethane() {
    // TODO Q3
    return null;
  }
}
