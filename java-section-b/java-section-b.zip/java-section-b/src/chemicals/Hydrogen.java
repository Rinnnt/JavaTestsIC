package chemicals;

import domain.producttypes.Element;

public class Hydrogen extends Element {

  public Hydrogen() {
    super();
  }
}
