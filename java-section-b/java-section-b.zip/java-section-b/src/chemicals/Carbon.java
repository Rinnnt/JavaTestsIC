package chemicals;

import domain.producttypes.Element;

public class Carbon extends Element {

  public Carbon() {
    super();
  }
}
