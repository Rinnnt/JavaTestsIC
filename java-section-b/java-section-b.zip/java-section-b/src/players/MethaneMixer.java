package players;

import domain.Player;
import exchange.Exchange;

public class MethaneMixer extends Player {

  public MethaneMixer(int thinkingTimeInMillis, Exchange exchange) {
    super(thinkingTimeInMillis, exchange);
  }

  @Override
  public void doAction() {
    // TODO: Q3
  }
}
