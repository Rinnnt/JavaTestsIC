package players;

import domain.Player;
import exchange.Exchange;

public class Chemist extends Player {

  public Chemist(int thinkingTimeInMillis, Exchange exchange) {
    super(thinkingTimeInMillis, exchange);
  }

  @Override
  public void doAction() {
    // TODO: Q3
  }
}
